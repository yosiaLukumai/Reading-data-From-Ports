from readFromComPortToNet import ReadFromComPorts
# com1 = ReadFromComPorts("COM1", 9600)
# com1.checkifTheComportisOpen()